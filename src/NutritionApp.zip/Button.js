import React, {useState}from 'react';

const RecipeNutritionCalculator = () => {
    const [ingredients, setIngredients] = useState([]);
    const [totalNutrition, setTotalNutrition] = useState(null);
    const [recipeName, setRecipeName] = useState('');
    const [ingredientName, setIngredientName] = useState('');
    const [quantity, setQuantity] = useState('');

    const handleAddIngredient = () => {
      if (ingredientName.trim()==='' || quantity.trim()===''){
          alert('Please enter both ingredient name an quantity.');
          return;
      }  

      setIngredients([...ingredients, {name: ingredientName.trim(), quantity:quantity.trim() }]);
      setIngredientName('');
      setQuantity('');


    };
    const handleCalculateNutrition = () => {
       if (ingredients.length === 0) {
           alert('Please add at least one ingredient before calculating nutrition.');
           return;
       }

       const total = ingredients.reduce(
           (acc, ingredient) => {
               acc.calories += Math.random() * 100;
               acc.protein += Math.random() * 10;
               acc.carbs += Math.random() * 20;
               acc.fat += Math.random() *5;     
               return acc;     
             },
             { calories: 0, protien: 0, carbs: 0, fat: 0 }
       );

       setTotalNutrition(total);
    };

    const handleClearIngredients =() => {
        setIngredients([]);
        setTotalNutrition(null);
    };

    return (
        <div>
            <h1>Recipe Nutrition Calculator</h1>

            {/* Recipe Name input */}
            <div>
                <label>
                    Recipe name:
                    <input
                        type="text"
                        value={recipeName}
                        onChange={(e)=> setRecipeName(e.target.value)}
                        placeholder="Enter recipe name"
                    />
                </label>
            </div>

            {/* Ingredient Input */}
            <div>
                <label>
                    Ingredient Name:
                    <input
                        type="text"
                        value={ingredientName}
                        onChange={(e) => setIngredientName(e.target.value)}
                        placeholder="Enter ingredient name"
                        />
                    </label>
                    <label>
                        Quantity:
                        <input
                            type="text"
                            value={quantity}
                            onChange={(e)=> setQuantity(e.target.value)}
                            placeholder="Enter quantity (e.g.,grams)"
                        />
                    </label>
                    <button onClick={handleAddIngredient}>Add Ingredient</button>
                </div>

            {/* Ingredients List */}
            <h3>Ingredients:</h3>
            <ul>
                {ingredients.map((ingredient, index)=> (
                    <li key={index}>
                        {ingredient.name} - {ingredient.quantity}
                    </li>
                ))}
            </ul>

            {/* Action Buttons */}
            <div>
                <button onClick={handleCalculateNutrition}>Calculate Nutrition</button>
                <button onClick={handleClearIngredients}>Clear Ingredients</button>
                <button onClick={() => alert('Recipe "${recipeName}" saved successfully!')}>
                    Save Recipe
                </button>
            </div>

            {/* Nutrition Details */}
            {totalNutrition && (
                <div>
                    <h3>Total Nutrition</h3>
                    <p>Calories: {totalNutrition.calories.toFixed(2)}</p>
                    <p>Protien: {totalNutrition.protien.toFixed(2)}g</p>
                    <p>Carbs: {totalNutrition.carbs.toFixed(2)}g</p>
                    <p>Fat: {totalNutrition.fat.toFixed(2)}g</p>
                </div>
            )}
        </div>
    );
};

export default RecipeNutritionCalculator;