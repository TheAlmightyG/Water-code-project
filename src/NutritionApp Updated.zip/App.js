import React from 'react';
import Button from './Button';

function App(){
  return(
    <div className="App">
    <h1>Welcome to the Recipe Nutrition Calculator</h1>
    <Button />
    </div>
  );
}

export default App;